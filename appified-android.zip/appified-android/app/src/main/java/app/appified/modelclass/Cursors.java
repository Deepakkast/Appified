package app.appified.modelclass;

class Cursors {
    public String before;
    public String after;

}
