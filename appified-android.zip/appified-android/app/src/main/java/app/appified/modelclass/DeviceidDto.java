package app.appified.modelclass;

public class DeviceidDto {
    public String deviceid;

    public DeviceidDto(String deviceid) {
        this.deviceid = deviceid;
    }

    public String getDeviceid() {
        return deviceid;
    }

    public void setDeviceid(String deviceid) {
        this.deviceid = deviceid;
    }
}
